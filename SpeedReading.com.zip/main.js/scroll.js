let animItems = document.querySelectorAll('._animation');
 if (animItems.length > 0) {
     window.addEventListener('scroll',animOnScroll);
    function animOnScroll(params) {
        for (let index = 0; index < animItems.length; index++){
            const animItem  = animItems[index];
            const animItemHeight = animItem.offsetHeight;
            const animItemOffset = offset(animItem).top;
            const animeStart = 4;

            let amineItemPoint = window.innerHeight - animItemHeight / animeStart;

            if(animItemHeight > window.innerHeight){
                amineItemPoint = window.innerHeight - animItemHeight / animeStart;
            }

            if((pageYOffset > animItemOffset - amineItemPoint) && pageYOffset < (animItemOffset + animItemHeight)){
               animItem.classList.add('_active'); 
            } /*else {
                animItem.classList.remove('_active');
            }*/
        }
    }
    function offset(el) {
        const rect = el.getBoundingClientRect(),
        scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
        scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        return { top: rect.top + scrollTop, left: rect.left + scrollLeft}
        
    }
    setTimeout(() => {
        animOnScroll();

    },10000);
   

 }