
$(Document).ready(function () {
  
  $('.buttonOrder , .ReadingLast .contacts').click(function () {
    $('.popups_inner').fadeIn(500);   
    
  });
  $('.close_popup').click(function () {
  $('.popups_inner').fadeOut(500);
  });
});

$(Document).ready(function () {
$('.slider').slick({
  arrows:false,
  dots:true,
  adaptiveHeight:true,
  speed:2000,
  easing:'ease',
  autoplay:true,
  autoplaySpeed:2000,
  pauseOnFocus:true,
  pauseOnHover:true,
  pauseOnDotsHover:true,

});
})

